<?php

$lang['copywrite'] = "&copy; 2020 Tyganeutronics, all rights reserved";

$lang['about'] = "About";
$lang['contact'] = "Contact";
$lang['faqs'] = "FAQ's";
$lang['support'] = "Support";

$lang['facebook'] = "Facebook";
$lang['twitter'] = "Twitter";
$lang['google'] = "Google";
